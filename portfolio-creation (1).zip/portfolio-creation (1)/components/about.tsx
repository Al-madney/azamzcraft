export default function About() {
  return (
    <section id="about" className="py-20 px-4 sm:px-6 lg:px-8 bg-accent/5">
      <div className="max-w-4xl mx-auto space-y-12">
        <div className="text-center space-y-4">
          <h2 className="text-4xl sm:text-5xl font-bold text-primary">About Me</h2>
          <p className="text-muted-foreground">My journey and expertise</p>
        </div>

        <div className="grid md:grid-cols-2 gap-12 items-center">
          <div className="space-y-6">
            <p className="text-lg text-foreground leading-relaxed">
              I'm a versatile creative professional specializing in web development, graphic design, and digital content
              creation. With a passion for building beautiful and functional digital experiences, I combine technical
              expertise with creative vision.
            </p>
            <p className="text-lg text-foreground leading-relaxed">
              Whether it's crafting a seamless web application, designing a compelling brand identity, or creating
              engaging content for social media, I approach every project with meticulous attention to detail and a
              commitment to excellence.
            </p>
            <p className="text-lg text-foreground leading-relaxed">
              I believe in the power of collaboration and love working with brands and individuals who are passionate
              about making an impact in the digital space.
            </p>
          </div>

          <div className="space-y-6">
            <div className="bg-background p-6 rounded-lg border border-border">
              <h3 className="text-lg font-bold text-primary mb-4">Experience</h3>
              <div className="space-y-4">
                <div>
                  <p className="font-semibold text-foreground">Web Development</p>
                  <p className="text-sm text-muted-foreground">
                    5+ years building responsive, high-performance web applications
                  </p>
                </div>
                <div className="border-t border-border pt-4">
                  <p className="font-semibold text-foreground">Graphic Design</p>
                  <p className="text-sm text-muted-foreground">
                    4+ years creating visual identities and digital designs
                  </p>
                </div>
                <div className="border-t border-border pt-4">
                  <p className="font-semibold text-foreground">Content Creation</p>
                  <p className="text-sm text-muted-foreground">
                    3+ years building engaged communities across platforms
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
