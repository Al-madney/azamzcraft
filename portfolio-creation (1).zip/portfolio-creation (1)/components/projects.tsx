"use client"

import { useState } from "react"
import Image from "next/image"

const projectCategories = ["All", "Web Dev", "Design", "Content"]

const projects = [
  {
    id: 1,
    title: "E-Commerce Platform",
    category: "Web Dev",
    description: "Full-stack NextJS e-commerce solution with Stripe integration",
    image: "/ecommerce-platform-website.jpg",
    tags: ["Next.js", "React", "Stripe", "TypeScript"],
  },
  {
    id: 2,
    title: "Brand Identity System",
    category: "Design",
    description: "Comprehensive visual identity and design system for startup",
    image: "/graphic-design-brand-identity.jpg",
    tags: ["Branding", "Design System", "UI/UX"],
  },
  {
    id: 3,
    title: "Social Media Campaign",
    category: "Content",
    description: "Influencer campaign reaching 500K+ engaged followers",
    image: "/social-media-influencer-content.jpg",
    tags: ["Social Media", "Content Creation", "Marketing"],
  },
  {
    id: 4,
    title: "Dashboard Application",
    category: "Web Dev",
    description: "Data visualization dashboard with real-time analytics",
    image: "/web-dashboard-analytics-application.jpg",
    tags: ["React", "TypeScript", "Charts"],
  },
  {
    id: 5,
    title: "Visual Design Package",
    category: "Design",
    description: "Complete UI kit and component library design",
    image: "/ui-design-component-library.jpg",
    tags: ["UI Design", "Components", "Figma"],
  },
  {
    id: 6,
    title: "Lifestyle Brand Collaboration",
    category: "Content",
    description: "Sponsored content series with premium partnerships",
    image: "/lifestyle-brand-influencer-collaboration.jpg",
    tags: ["Partnerships", "Brand Collaboration", "Creation"],
  },
]

export default function Projects() {
  const [activeCategory, setActiveCategory] = useState("All")

  const filteredProjects = activeCategory === "All" ? projects : projects.filter((p) => p.category === activeCategory)

  return (
    <section id="work" className="py-20 px-4 sm:px-6 lg:px-8 bg-background">
      <div className="max-w-6xl mx-auto space-y-12">
        <div className="text-center space-y-4">
          <h2 className="text-4xl sm:text-5xl font-bold text-primary">Selected Work</h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            A showcase of my best projects across web development, design, and content creation.
          </p>
        </div>

        <div className="flex justify-center gap-4 flex-wrap">
          {projectCategories.map((category) => (
            <button
              key={category}
              onClick={() => setActiveCategory(category)}
              className={`px-6 py-2 rounded-full transition-all ${
                activeCategory === category
                  ? "bg-primary text-primary-foreground"
                  : "bg-secondary text-secondary-foreground hover:bg-accent"
              }`}
            >
              {category}
            </button>
          ))}
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {filteredProjects.map((project) => (
            <div
              key={project.id}
              className="group cursor-pointer bg-card rounded-lg overflow-hidden border border-border hover:border-primary transition-all hover:shadow-lg"
            >
              <div className="relative h-64 overflow-hidden bg-muted">
                <Image
                  src={project.image || "/placeholder.svg"}
                  alt={project.title}
                  fill
                  className="object-cover group-hover:scale-105 transition-transform duration-300"
                />
              </div>
              <div className="p-6 space-y-4">
                <div>
                  <h3 className="text-xl font-bold text-foreground group-hover:text-primary transition-colors">
                    {project.title}
                  </h3>
                  <p className="text-sm text-muted-foreground mt-2">{project.category}</p>
                </div>
                <p className="text-foreground text-sm">{project.description}</p>
                <div className="flex flex-wrap gap-2">
                  {project.tags.map((tag) => (
                    <span key={tag} className="px-3 py-1 bg-secondary text-secondary-foreground text-xs rounded-full">
                      {tag}
                    </span>
                  ))}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
