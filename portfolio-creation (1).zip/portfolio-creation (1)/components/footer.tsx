export default function Footer() {
  return (
    <footer className="bg-primary text-primary-foreground py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-6xl mx-auto">
        <div className="grid md:grid-cols-3 gap-8 mb-8">
          <div>
            <h3 className="text-lg font-bold mb-4">AZAZM CRAFT</h3>
            <p className="opacity-80">Crafting digital experiences with passion and precision.</p>
          </div>
          <div>
            <h4 className="font-semibold mb-4">Quick Links</h4>
            <ul className="space-y-2 opacity-80">
              <li>
                <a href="#work" className="hover:opacity-100 transition-opacity">
                  Work
                </a>
              </li>
              <li>
                <a href="#about" className="hover:opacity-100 transition-opacity">
                  About
                </a>
              </li>
              <li>
                <a href="#skills" className="hover:opacity-100 transition-opacity">
                  Skills
                </a>
              </li>
              <li>
                <a href="#contact" className="hover:opacity-100 transition-opacity">
                  Contact
                </a>
              </li>
            </ul>
          </div>
          <div>
            <h4 className="font-semibold mb-4">Follow</h4>
            <ul className="space-y-2 opacity-80">
              <li>
                <a href="#" className="hover:opacity-100 transition-opacity">
                  Instagram
                </a>
              </li>
              <li>
                <a href="#" className="hover:opacity-100 transition-opacity">
                  LinkedIn
                </a>
              </li>
              <li>
                <a href="#" className="hover:opacity-100 transition-opacity">
                  Twitter
                </a>
              </li>
              <li>
                <a href="#" className="hover:opacity-100 transition-opacity">
                  GitHub
                </a>
              </li>
            </ul>
          </div>
        </div>
        <div className="border-t border-primary-foreground/20 pt-8 text-center opacity-80">
          <p>&copy; 2025 AZAZM CRAFT. All rights reserved.</p>
        </div>
      </div>
    </footer>
  )
}
