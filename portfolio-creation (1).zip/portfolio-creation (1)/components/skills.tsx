export default function Skills() {
  const skillCategories = [
    {
      category: "Web Development",
      skills: ["React", "Next.js", "TypeScript", "Tailwind CSS", "Node.js", "PostgreSQL"],
    },
    {
      category: "Design",
      skills: ["Figma", "Adobe Creative Suite", "UI/UX Design", "Branding", "Design Systems", "Prototyping"],
    },
    {
      category: "Content Creation",
      skills: [
        "Social Media Strategy",
        "Video Editing",
        "Photography",
        "Copywriting",
        "Community Management",
        "Analytics",
      ],
    },
    {
      category: "Other",
      skills: ["Project Management", "Client Communication", "SEO", "Performance Optimization", "Testing", "Git"],
    },
  ]

  return (
    <section id="skills" className="py-20 px-4 sm:px-6 lg:px-8 bg-background">
      <div className="max-w-6xl mx-auto space-y-12">
        <div className="text-center space-y-4">
          <h2 className="text-4xl sm:text-5xl font-bold text-primary">Skills & Expertise</h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            A diverse set of skills honed through years of professional experience
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {skillCategories.map((cat, idx) => (
            <div key={idx} className="bg-card p-8 rounded-lg border border-border">
              <h3 className="text-xl font-bold text-primary mb-6">{cat.category}</h3>
              <div className="flex flex-wrap gap-3">
                {cat.skills.map((skill) => (
                  <span
                    key={skill}
                    className="px-4 py-2 bg-primary/10 text-primary rounded-full text-sm font-medium hover:bg-primary/20 transition-colors"
                  >
                    {skill}
                  </span>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
